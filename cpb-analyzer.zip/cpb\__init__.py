"""CPB Analyzer package."""
